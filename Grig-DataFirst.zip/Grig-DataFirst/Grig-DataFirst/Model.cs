﻿namespace Grig_DataFirst
{
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class Model : DbContext
    {
       
        public Model()
            : base("name=Model")
        {
        }


        public DbSet<Student> UserStud { get; set; }
    }

    public class Student
    {
      
        public int ID { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Group { get; set; }
        public string Age { get; set; }

    }
}